let blocCouleur = document.getElementById("couleur");
let score = document.getElementById("score");
let reponses = [...document.getElementsByClassName("reponse")];
let compteurScore=0;

// Liste des couleurs disponibles
const couleurs = ['blue', 'red', 'yellow', 'green', 'orange', 'purple', 'black', 'white', 'beige', 'gray', 'brown', 'pink'];


// Fonction pour générer une couleur aléatoire
function getRandomColor() {
 const randomIndex = Math.floor(Math.random() * couleurs.length);
return couleurs[randomIndex];
}


// Utilisation de la fonction pour générer une couleur aléatoire
const randomColor = getRandomColor();


// Affichage de la couleur aléatoire générée
console.log(randomColor);


const initialiser = () => {
    score.textContent = compteurScore;
    let reponseCorrecte = Math.floor(Math.random() * 4);   //Entre 0 et 3

    reponses.forEach((rep) => (rep.textContent = randomColor));
}